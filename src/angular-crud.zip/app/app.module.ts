import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { ListEmployeesComponent } from './employee/list-employees.component';
import { ShowEmployeesComponent } from './employee/show-employees.component';
import { CreateEmployeeComponent } from './employee/create-employee.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AutoGrowDirective } from './directives/auto-group.directives';
// import  { RangeValidatorDirective } from './directives/range-validator.directives';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { BsDatepickerModule} from 'ngx-bootstrap/datepicker';

const appRoute: Routes = [
  { path: 'list', component: ListEmployeesComponent },
  { path: 'create', component: CreateEmployeeComponent },
  { path : '', redirectTo : '/list', pathMatch : 'full' }

]

@NgModule({
  declarations: [
    AppComponent,
    ListEmployeesComponent,
    ShowEmployeesComponent,
    CreateEmployeeComponent,
    AutoGrowDirective,
    // RangeValidatorDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    AppRoutingModule,
    RouterModule.forRoot(appRoute)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
