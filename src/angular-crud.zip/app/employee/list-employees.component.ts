import { Component, OnInit } from '@angular/core';
import {IEmployee} from './employee-interface';
import {EmployeeServices} from './employee-services';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css'],
  providers: [EmployeeServices]
})
export class ListEmployeesComponent implements OnInit {
  empName : string = '';
  employeeList: IEmployee[];
  // empItem: any;
  // empIndex: number = 0;
  
  constructor(public _empService: EmployeeServices) { }

  ngOnInit() {
    this._empService.getEmployeeList().subscribe((data) => {
      this.employeeList = data;
      // this.empItem = this.employeeList[this.empIndex];
    });
  }

  showEmpName(data) {
    console.log('parent component data: ', data);
    this.empName = data;
  }
  
  // loadNextEmpItem() {
  //   console.log('this.empIndex:', this.empIndex);
  //   this.setEmpIndex();
  //   this.empItem = this.employeeList[this.empIndex];
  // }
  
  // setEmpIndex() {
  //   console.log('len: ', this.employeeList.length, 'index: ', this.empIndex)
  //   if((this.employeeList.length-1) <= this.empIndex) {
  //     this.empIndex = 0;
  //   } else {
  //     this.empIndex += 1;
  //   }
  // }

  onUpdateEmpDetails(id) {
    console.log('onUpdateEmpDetails: ', id)
  }

  onDeleteEmpDetails(id) {
    console.log('onDeleteEmpDetails: ', id)
    this._empService.deleteEmployeeList(id).subscribe((data) => {
      console.log('onDeleteEmpDetails success: ', data)
      this.employeeList = data;
    });
  }

}
