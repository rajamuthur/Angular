import { Component, OnInit, OnChanges, Input, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { IEmployee } from './employee-interface';

@Component({
    selector: 'show-emp-detail',
    templateUrl: './show-employees.component.html',
})

export class ShowEmployeesComponent implements OnInit, OnChanges {
    private _empDetails: IEmployee;
    @Input()
    set empDetails(val: IEmployee) {
        this._empDetails = val;
    }
    get getEmpDetail() {
        return this._empDetails;
    }    

    @Output() empNameEmitter = new EventEmitter<string>();


    constructor(){

    }

    ngOnInit() {

    }

    ngOnChanges(val: SimpleChanges) {
        console.log('val: ', val)
    }

    passDataToParent(emp: IEmployee) {
        console.log('emp: ', emp)
        this.empNameEmitter.emit(emp.name)
    }

    getNameAndAge() : string {
        console.log('getNameAndAge: ', this._empDetails);
        return 'Name is: '+this._empDetails.name+ ' and age is: ' + this._empDetails.age;
    }

}