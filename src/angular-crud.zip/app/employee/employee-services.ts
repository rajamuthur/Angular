import {Injectable} from '@angular/core';
import {IEmployee} from './employee-interface';
// import { Http, Response } from '@angular/http';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()

export class EmployeeServices {
    // constructor(private _http: Http){}
    constructor(private _http: HttpClient){}

    getEmployeeList() : Observable<IEmployee[]>{
        return this._http.get<IEmployee[]>('http://localhost:3000/api/courses/');
        // return this._http.get('http://localhost:3000/api/courses/').pipe(map((resp : Response) => <IEmployee[]>resp.json()));
    }

    addEmployeeList(data) : Observable<IEmployee[]> {
        console.log('addEmployeeList data: ', data);
        return this._http.post<IEmployee[]>('http://localhost:3000/api/courses/', data, {
            headers: new HttpHeaders({
                'Content-Type':  'application/json'
            })
        });
    }

    deleteEmployeeList(id) : Observable<IEmployee[]> {
        console.log('deleteEmployeeList id: ', id);
        return this._http.delete<IEmployee[]>('http://localhost:3000/api/courses/'+id);
    }

    getEmployeeList1() : IEmployee[]{
        return [
            {
              name : 'RR',
              id: 1,
              gender: 'male',
              preference : 'phoneNumber',
              phoneNumber : 123,
              isActive : true,
              age: 21,
              dob : new Date('10/13/2018')
            },
            {
              name : 'Ram',
              id: 2,
              gender: 'male',
              age: 31,
              email: 'rr@gmail.com',
              preference : 'email',
              phoneNumber : 3321334243,
              isActive : true,
              dob : new Date('3/20/2018')
            }
          ];
    }
}